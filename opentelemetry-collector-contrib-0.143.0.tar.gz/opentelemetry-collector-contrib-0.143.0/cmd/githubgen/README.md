⚠️ This executable has moved to [opentelemetry-go-build-tools](https://github.com/open-telemetry/opentelemetry-go-build-tools/tree/main/githubgen).

See https://github.com/open-telemetry/opentelemetry-collector-contrib/issues/37294.
