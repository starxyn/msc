// Copyright The OpenTelemetry Authors
// SPDX-License-Identifier: Apache-2.0

package testdata

type MapConfig struct {
	Settings map[string]int `mapstructure:"settings"`
}
