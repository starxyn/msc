import vitejsPluginReact from '@vitejs/plugin-react';

export default {
	server: {
		open: 'index.html'
	},
	plugins: [vitejsPluginReact()]
};
